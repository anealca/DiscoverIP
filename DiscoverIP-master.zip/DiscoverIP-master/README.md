# DiscoverIP
This is a repository designed to figure out how to automatically connect to a server over IP
